# Changelog

## v1.0.0
- 初始版本：ima-skill-forge 元技能。
- 七步锻造工作流：入库 → 整合 → 蒸馏 → 锻造 SKILL.md → 脚手架 → 校验 → 打包分发。
- 内置 scripts：scaffold.py / validate.py / package.py。
- 内置 references：ima-ingest / slicing-spec / skill-template / distribution / compliance。
- 内置 assets：skill-readme-template.md。
- 支持合规双版本（官方版 / GitHub 完整版）。
