# ima-skill-forge

> 把你的 ima 知识库（或任何本地导出的知识文件夹）自动整合、自动理解，锻造出一个
> 符合 git 上传规范、可直接口令安装的技能包——达到 dontbesilent/dbskill 那种
> “说一句口令就能装”的效果。

这是一个 **“造技能的技能”（meta-skill）**。它接收你 ima 知识库里导出的文件，在 WorkBuddy 中完成
整合、蒸馏、锻造、打包，输出一个干净的技能仓库，push 到 GitHub 后别人一句话即可装好。

## 它能做什么

- **自动整合**：把散乱的 ima 导出文件去重、归一（UTF-8）、合并为工作语料。
- **自动理解**：按知识切片规范（500–800 字 / 单点 / 关键词前置）把语料蒸馏成可被检索的 `references/`。
- **自动锻造**：按标准模板生成规范 `SKILL.md`（角色 / 能做 / 不能做 / 工作流 / 示例 / 兜底 / 免责）。
- **自动分发**：一键脚手架 → 校验 → 打包成发布 zip，并打印可直接复制的 GitHub 安装口令。
- **合规双版本**：需要放微信/手机/二维码时，自动区分“官方版（删联系方式）”与“GitHub 完整版（放全）”。

## 安装（一句话口令）

```
帮我安装 GitHub 上的 你的用户名/ima-skill-forge 技能包，
如果没有 git 就直接下载 Release 里的 zip：
https://github.com/你的用户名/ima-skill-forge/releases/latest/download/ima-skill-forge.zip
解压到本地用户技能目录，并确保 references 子目录一并保留。
安装完成后，列出你装好的技能名称和用途。
```

手动安装：下载 Release 的 `ima-skill-forge.zip` → 解压（第一层即 `ima-skill-forge/`）→
放到 WorkBuddy 技能目录 `C:\Users\用户名\.workbuddy\skills\`（或对应平台目录）→ 重启客户端。

## 怎么用

装好后，对 WorkBuddy 说类似：

> “把我的 ima 知识库（路径 D:/ima-export/反洗钱合规）锻造成一个技能，领域叫反洗钱合规科普。”

它会按七步工作流执行，并在关键节点向你确认。最终产出位于你指定的目录，含可直接 push 的技能包。

## 仓库结构

```
ima-skill-forge/
├── SKILL.md                  # 元技能本体（七步锻造工作流）
├── scripts/
│   ├── scaffold.py           # 生成产物技能包骨架
│   ├── validate.py           # 校验产物是否符合规范
│   └── package.py            # 打包成发布 zip + 打印安装口令
├── references/               # 方法论：入库/切片/模板/分发/合规
├── assets/
│   └── skill-readme-template.md  # 产物 README 模板
├── README.md / LICENSE / CHANGELOG.md
```

## 底层方法论来源

- 《技能上架与分发全套分析与操作流程》：技能结构标准、SKILL.md 模板、双版本合规策略、GitHub 六步法与口令。
- 《一个链接把整个知乎专栏搬进 ima 知识库》：知识入库 / 整合 / 理解的工作流范式。

---
*本技能由 WorkBuddy 锻造，遵循公开科普定位。*
