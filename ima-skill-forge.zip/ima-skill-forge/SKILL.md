---
name: ima-skill-forge
description: |
  把个人 ima 知识库（或任何本地导出的知识文件夹）自动整合、自动理解，锻造出一个符合
  git 上传规范、可直接安装分发的技能包——达到 dontbesilent/dbskill 那种“说一句口令就能装”的效果。
  当用户想把 ima 知识库内容 / 笔记 / 资料批量做成可复用的技能，或提到
  “把我的 ima 知识库做成技能”“把这批资料锻造成 skill”“生成一个能口令安装的技能包”时使用本技能。
  不处理：平台官方上架审核代填、付费收款账户开通、非知识库类（纯代码工具）技能的开发。
---

# ima-skill-forge（ima 知识库 → 可分发技能 锻造炉）

## Overview

这是一个**“造技能的技能”（meta-skill）**。它接收用户 ima 知识库里导出的文件作为输入，在
WorkBuddy 中完成**自动整合**（去重、归一、合并）与**自动理解**（切分知识、提炼规则），
然后**锻造**出一个干净的技能仓库：内含规范化的 `SKILL.md`、`references/`、`scripts/`、
`assets/`、`README.md`、`LICENSE`、`CHANGELOG.md`，并打包成可直接 push 到 GitHub、用口令
安装的 zip。最终效果对标 DBS（dontbesilent/dbskill）——别人一句话即可装好。

核心思想来自两份底层方法论：
- 《技能上架与分发全套分析与操作流程》：技能结构标准、SKILL.md 模板、双版本合规策略、GitHub 六步法与口令生成。
- 《一个链接把整个知乎专栏搬进 ima 知识库》：知识入库 / 整合 / 理解的工作流范式（清单核对 → 逐条入库 → 打标签分类）。

## When to use（触发场景）

- 用户想把 ima 知识库内容转成可复用、可分发的技能。
- 用户说：“把我的 ima 知识库做成技能”“把这批资料锻造成一个 skill”“从我的笔记生成一个能口令安装的技能包”。
- 用户已有一堆本地资料（markdown / txt / docx / pdf），想自动整理成一个规范技能。

## Resources（本技能自带资源）

- `references/ima-ingest.md` — 如何从 ima 把内容落到本地、整合去重、编码归一（Step 0–1 的依据）。
- `references/slicing-spec.md` — 知识切片规范（500–800 字、单点、关键词前置）与 SKILL.md 编写方法论（Step 2–3 的依据）。
- `references/skill-template.md` — 生成产物 `SKILL.md` 的完整模板（角色 / 能做 / 不能做 / 工作流 / 输出格式 / 示例 / 兜底 / 免责）。
- `references/distribution.md` — GitHub 六步法、四级口令对照、安装口令模板、各平台目录与大小上限（Step 6 的依据）。
- `references/compliance.md` — 双版本策略与红线汇总（官方版删联系方式，GitHub 完整版放全）（Step 7 的依据）。
- `assets/skill-readme-template.md` — 生成产物 `README.md` 模板（含安装口令占位符）。
- `scripts/scaffold.py` — 一键生成产物技能包的目录骨架与占位文件。
- `scripts/validate.py` — 校验产物技能包是否符合规范（编码、命名、行数、凭证、目录结构）。
- `scripts/package.py` — 把产物技能包打成发布 zip（第一层即技能目录），并打印安装口令。

## Workflow（锻造七步）

> 全程用中文与用户沟通；长流程在关键节点设“确认门”，不要一路自动跑到底。

### Step 0 — 入库（把 ima 内容落到本地）
读取 `references/ima-ingest.md`，按其中方法把用户的 ima 知识库内容导出为本地文件夹（markdown / txt / docx / pdf）。
向用户确认：导出路径、目标知识领域名称、是否要保留原文文件。
若用户直接提供了已导出的文件夹或粘贴的内容，跳过导出、直接进入 Step 1。

### Step 1 — 整合（归一 + 去重）
读取 `references/ima-ingest.md` 的整合规范，对本地文件执行：
1. 编码统一为 **UTF-8**（非 UTF-8 文件先转码，避免乱码）。
2. 同名 / 近似内容**去重**（参考文档2的“先查重”原则）；记录删除项让用户确认。
3. 合并为一个工作语料（按主题或时间排序），删除空文件与占位目录。
4. 统计语料规模（篇数 / 总字数），用于决定 Step 2 的切片粒度与 Step 3 是否拆分 references。

### Step 2 — 理解 & 蒸馏（切分成 references）
读取 `references/slicing-spec.md`，把 Step 1 的语料切分为**单一知识点切片**：
- 每片 500–800 字，只讲一个点，关键词放段落开头。
- 文件命名英文 kebab-case（如 `aml-suspicious-transaction.md`）。
- 若生成内容超过约 2000 字或 3 个以上独立主题，按主题分到多个切片文件写入产物的 `references/`。
- 这一步是“理解”的核心：把散乱资料提炼成可被技能按需检索的知识单元。

### Step 3 — 锻造 SKILL.md（用模板）
读取 `references/skill-template.md`，为产物技能写 `SKILL.md`：
- 填 frontmatter：`name`（kebab-case）、`description`（功能 + 触发 + 排除 三段式，见 slicing-spec）。
- 写**角色**、**能做**、**不能做（硬边界）**、**工作流程（含确认门）**、**输出格式**、**至少 2 个示例**、**兜底与转人工**、**免责声明**（标注最后更新时间）。
- 若 `SKILL.md` 正文预计超过 **400 行**，把长规则拆进 `references/`，SKILL.md 仅留索引与核心指令。
- description 必须遵循三段式：提供什么 / 何时触发 / 不处理什么。

### Step 4 — 脚手架（生成产物骨架）
运行：
```bash
python3 scripts/scaffold.py <产物目录> --name <产物技能名> [--title "中文标题"]
```
该脚本会创建 `SKILL.md`（含模板注释）、`references/`、`scripts/`、`assets/`、
`README.md`、`LICENSE`（MIT）、`CHANGELOG.md` 占位。然后：
- 把 Step 2 的切片写入产物的 `references/`；
- 把 Step 3 写好的 `SKILL.md` 覆盖到产物；
- 把 `assets/skill-readme-template.md` 渲染为产物的 `README.md`（填入技能名、口令占位、简介）。

### Step 5 — 校验（确保 git 可直接用）
运行：
```bash
python3 scripts/validate.py <产物目录>
```
逐项检查并修复：UTF-8 编码、kebab-case 命名、SKILL.md ≤400 行（超限提示拆分）、
无空目录、无 API Key / 密码 / Cookie 等敏感凭证、压缩包第一层即技能目录、大小上限
（ima ≤10MB / WorkBuddy ≤3MB / 豆包无明确上限）。全部通过后再进入 Step 6。

### Step 6 — 打包 & 分发（GitHub 六步法）
读取 `references/distribution.md`，运行：
```bash
python3 scripts/package.py <产物目录> [--dist ./dist]
```
该脚本把产物打成 **第一层即技能目录** 的 zip，并打印可直接复制的安装口令（L2/L3 合并模板）。
然后引导用户完成 GitHub 六步法：注册 → 新建 Public 仓库 → 传文件（README/LICENSE/CHANGELOG/skills/）→
**发 Release（Tag v1.0.0，Attach zip，不可跳过）** → 写安装口令进 README → 试装验证（用只有 references 才有答案的问题）。

### Step 7 — 合规双版本（仅当用户要放联系方式时）
读取 `references/compliance.md`。若用户要在技能里放微信 / 手机 / 二维码 / 营销话术：
- **官方版**（ima / 豆包 / Coze / WorkBuddy 上架）：删除全部联系方式，引流改中性表述
  “请通过平台官方渠道预约一对一咨询”。
- **GitHub 完整版**（自己渠道 / 口令卡片推）：保留微信 + 手机 + 二维码 + 自由营销话术，二维码放 `assets/`。
两个版本用同一份 `references/` 知识，仅 SKILL.md 角色段与 README 营销区块不同。

## 交付 checklist（结束前自检）

- [ ] 产物 `SKILL.md` 含完整 frontmatter 与三段式 description。
- [ ] `references/` 切片均为单点知识、kebab-case、UTF-8。
- [ ] `README.md` 含可复制安装口令；`LICENSE`(MIT)、`CHANGELOG.md` 齐备。
- [ ] `validate.py` 全绿；`package.py` 生成的 zip 第一层即技能目录。
- [ ] 若要联系方式，已按双版本策略分别产出。
- [ ] 已用“只有 references 才有答案”的问题做一次试装验证。
