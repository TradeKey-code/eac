# {SKILL_TITLE}

> {SKILL_ONE_LINE} —— 由 ima-skill-forge 自动锻造。

## 这是什么
{用 2–3 句说清这个技能解决什么问题、面向谁、能给你什么。}

## 你能获得什么
- {价值点 1}
- {价值点 2}
- {价值点 3}

## 安装（一句话口令）

把下面这段直接发给支持 GitHub 安装的 AI（豆包工作模式 / 千问办公 / WorkBuddy 等）：

```
帮我安装 GitHub 上的 {GITHUB_USER}/{REPO_NAME} 技能包，
如果没有 git 就直接下载 Release 里的 zip：
https://github.com/{GITHUB_USER}/{REPO_NAME}/releases/latest/download/{PACKAGE_ZIP}
解压到本地用户技能目录，并确保 references 子目录一并保留。
安装完成后，列出你装好的技能名称和用途。
```

> 退路：若上面不行，直接下载 zip 手动放到技能目录（见下方「手动安装」）。

## 手动安装
1. 下载 Release 中的 `{PACKAGE_ZIP}`。
2. 解压，确保第一层直接是技能目录（不要多套一层文件夹）。
3. 把该目录放到对应平台的技能目录：
   - WorkBuddy：`C:\Users\用户名\.workbuddy\skills\`（≤3MB）
   - 千问办公：`~/.qwenworkcn/skills/`
   - 豆包 / 其他：见技能说明或平台文档
4. 重启客户端，验证安装。

## 验证是否装好
问它一个只有本技能 references 里才有答案的问题，例如：
> {VERIFY_QUESTION}

若回答与参考资料一致，说明 references 被完整读入；否则检查解压层级。

## 使用场景示例
- {场景 1}
- {场景 2}

## 更新
改文件 → 重新打包 zip → 新建 Release（Tag 升一档，如 v1.1.0）→ 再说一遍口令即升级。

---
*本技能由 ima-skill-forge 从个人知识库自动锻造，遵循公开科普定位。*
