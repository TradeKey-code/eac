# 参考：GitHub 分发六步法、口令与平台矩阵（Step 6）

本文件是 ima-skill-forge 在“打包分发”阶段的依据，提炼自《技能上架与分发全套分析与操作流程》
第二章与第四章。目标是让产物技能达到 **DBS（dontbesilent/dbskill）效果**：一句话口令即可安装。

## A. 三种触达方式（先认清要哪种效果）

| 方式 | 本质 | 能否像 DBS 口令安装 | 能否显示在技能选择栏 |
|---|---|---|---|
| ① 官方上架 | 云端引用，平台市场 | ❌ | ✅（唯一能给“一个词/点一下”体验） |
| ② GitHub 分发 | 本机下载解压写目录 | ✅（DBS 本体就是这条路） | ❌（社区传播，非陈列） |
| ③ 本地上传 | 手动放目录 | ❌（仅自己） | ❌ |

**结论**：想最像 DBS 的“社区传播 + 口令安装”走 ②；想有“技能选择栏 / 广场”陈列走 ①。两条都做。

## B. GitHub 六步法（全程不需写代码）

1. **注册 GitHub**：github.com → Sign up；用户名建议短（如 `eac-skill`，会进下载链接）。
2. **新建仓库**：`+ → New repository`；Repository name 英文数字短横线无空格；**必须 Public**；不要勾 Add a README。
3. **传文件**：仓库页 “uploading an existing file” 拖入 `README.md` / `LICENSE` / `CHANGELOG.md` / `skills/` 整个文件夹 → Commit。
4. **打包发 Release（关键，不可跳过）**：进 `skills` 上级目录选中技能文件夹压缩成 zip，**第一层必须直接是技能目录**；右侧 Releases → Create a new release；Tag `v1.0.0`；Attach binaries 拖 zip；Publish。只有这步能拿到永久下载地址。
5. **写安装口令放进 README**（做成代码块，方便一键复制）。
6. **试装验证（必做）**：问一个只有 `references/` 才有答案的问题，答得上来且与 references 一致 = 读取成功；答不上来/胡编 = 解压层级有问题，回去查第 4 步。

## C. 四级口令长度对照

| 级别 | 长什么样 | GitHub 能做到吗 | 靠什么 |
|---|---|---|---|
| L1 最短 | “装 DBS” | 做不到 | 需平台别名或极出名 |
| L2 实用 | “装 用户名/仓库名 这个技能” | 可以 | 作者名+项目名，AI 自拼 URL |
| L3 完整 | 带完整网址的一大段 | 可以（最稳） | 兼容性最好 |
| L4 终极 | 商店搜名字点安装 | 官方上架后才行 | 平台收录 |

**最短化五技巧**：① 仓库名短独特好念；② 口令用 `用户名/仓库名`（GitHub 标准写法）；
③ 口令里留“退路”句（“如果没有 git 就直接下载 zip”）；④ archive 地址需补“解压后进下一层目录再安装”；
⑤ 做口令卡片 / 二维码，扫一下自动复制。

## D. 通用安装口令模板（L2/L3 合并，package.py 自动生成）

```
帮我安装 GitHub 上的 你的用户名/你的仓库名 技能包，
如果没有 git 就直接下载 Release 里的 zip：
https://github.com/你的用户名/你的仓库名/releases/latest/download/你的包.zip
解压到本地用户技能目录，并确保 references 子目录一并保留。
安装完成后，列出你装好的技能名称和用途。
```

## E. 各平台技能目录与大小上限（同一份包多平台复用）

| 平台 | 技能目录 / 入口 | 大小上限 |
|---|---|---|
| 豆包 | open.doubao.com / skill.doubao.com | 无明确上限 |
| 千问办公 | `~/.qwenworkcn/skills/` | — |
| WorkBuddy | `~/.workbuddy/skills/`（Win: `C:\Users\用户名\.workbuddy\skills\`） | ≤3MB |
| ima | 云端知识号 | ≤10MB |
| 扣子 | 云端技能商店 | — |
| Qwen Code | `~/.qwen/skills/` | — |
| Trae / CodeBuddy / 灵码 / Qoder / Kimi CLI | 各自 `~/.xxx/skills/` | — |

每换一个平台，都按 B.6 验证 `references/` 有没有被读到。

## F. 红线（GitHub 分发）

- 仓库**必须 Public**（Private 别人拿不到下载链接，全白做）。
- zip **第一层不能多套文件夹**（安装失败最常见原因）。
- **Release 不能省**（否则拿不到永久地址）；更新 = 改文件 → 重新打包 → 新建 Release（Tag 升 v1.1.0）→ 用户再说一遍口令即升级。
