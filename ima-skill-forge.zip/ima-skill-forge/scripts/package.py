#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
package.py — 把「产物技能」打包成发布 zip（第一层即技能目录），并打印安装口令。

用法:
    python3 scripts/package.py <skill_dir> [--dist ./dist] [--user <github用户名>]

产物:
    <dist>/<name>.zip  —— 解压后第一层直接是技能目录（符合平台安装要求）。

同时打印可直接复制的 L2/L3 合并安装口令，以及 GitHub 六步法提醒。
退出码 0 = 成功；1 = 失败。
"""
import os
import sys
import zipfile
import argparse


def zip_skill(skill_dir, dist_dir, name):
    os.makedirs(dist_dir, exist_ok=True)
    zip_path = os.path.join(dist_dir, f"{name}.zip")
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as z:
        for dirpath, _, filenames in os.walk(skill_dir):
            for fn in filenames:
                fp = os.path.join(dirpath, fn)
                # 关键：arcname 第一层 = 技能目录名
                arc = os.path.relpath(fp, os.path.dirname(skill_dir))
                z.write(fp, arc)
    return zip_path


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("skill_dir")
    ap.add_argument("--dist", default="./dist")
    ap.add_argument("--user", default="你的用户名", help="GitHub 用户名（用于生成口令）")
    args = ap.parse_args()

    root = os.path.abspath(args.skill_dir)
    if not os.path.isdir(root):
        print(f"[ERROR] 目录不存在: {root}")
        sys.exit(1)
    name = os.path.basename(root.rstrip("/\\"))

    zip_path = zip_skill(root, args.dist, name)

    # 校验 zip 第一层
    with zipfile.ZipFile(zip_path) as z:
        tops = {n.split("/")[0] for n in z.namelist() if n}
    if name not in tops or len(tops) > 1:
        print(f"[ERROR] zip 第一层不正确: {tops}（应仅含 {name}/）")
        sys.exit(1)

    size_kb = os.path.getsize(zip_path) / 1024
    print(f"[OK] 已打包: {zip_path}  ({size_kb:.1f} KB)")
    print(f"     zip 第一层 = {name}/  ✅")

    print("\n=== 安装口令（L2/L3 合并，复制给用户）===\n")
    print("```")
    print(f"帮我安装 GitHub 上的 {args.user}/{name} 技能包，")
    print("如果没有 git 就直接下载 Release 里的 zip：")
    print(f"https://github.com/{args.user}/{name}/releases/latest/download/{name}.zip")
    print(f"解压到本地用户技能目录，并确保 references 子目录一并保留。")
    print("安装完成后，列出你装好的技能名称和用途。")
    print("```")

    print("\n=== GitHub 六步法提醒 ===")
    print("1) 注册 GitHub，用户名建议短；2) 新建 Public 仓库(同名, 不要勾 README)；")
    print("3) 上传 README/LICENSE/CHANGELOG/skills 整个文件夹；")
    print("4) 发 Release: Tag v1.0.0，Attach 这个 zip（不可跳过，拿永久地址）；")
    print("5) 把上方口令写进 README；6) 用'只有 references 才有答案'的问题试装验证。")
    sys.exit(0)


if __name__ == "__main__":
    main()
