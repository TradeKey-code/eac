#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
scaffold.py — 为 ima-skill-forge 生成的「产物技能」创建标准目录骨架。

用法:
    python3 scripts/scaffold.py <skill_dir> [--name <name>] [--title "中文标题"]

说明:
    <skill_dir> 是要创建的技能文件夹完整路径（其最后一段应为技能名）。
    脚本会创建 SKILL.md(含模板注释)、references/、scripts/、assets/、
    README.md、LICENSE(MIT)、CHANGELOG.md。
    之后由 Agent 把 references 切片与正式 SKILL.md 写入，再跑 validate.py / package.py。
"""
import os
import sys
import argparse

SKILL_MD = """\
---
name: {name}
description: |
  [TODO] 提供……的基础概念与科普。
  [TODO] 当用户提到……，或询问……时使用本技能。
  [TODO] 即使用户没有明确说关键词，只要意图涉及……，也应触发。
  不处理：具体实操方案、报价、渠道对接、通过率承诺。
---

# {title}

## 角色
（一句话定义 AI 是谁、风格如何）

## 能做
1. ...

## 不能做（硬边界）
1. ...

## 工作流程
Step 1 ...（含确认门）
Step 2 ...

## 输出格式
（明确格式，让用户可预期）

## 示例
示例 1：输入 → 预期输出
示例 2：输入 → 预期输出

## 兜底与转人工
（浅层问题完整解答；问到落地/实操/疑难时，停止解答并引导线下咨询）

## 免责声明
（公开科普，不构成官方意见/商业落地方案/法律合规建议；最后更新时间：YYYY-MM-DD）

---
模板详见本技能的 references/skill-template.md；写法规范见 references/slicing-spec.md。
"""

LICENSE_MD = """\
MIT License

Copyright (c) {year} {author}

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
"""

CHANGELOG_MD = """\
# Changelog

## v1.0.0
- 初始版本：由 ima-skill-forge 从个人知识库自动锻造。
"""

README_MD = """\
# {title}

> [TODO] 一句话说明这个技能解决什么问题。

## 安装（一句话口令）
[由 Agent 依据 assets/skill-readme-template.md 渲染，填入 GitHub 用户名/仓库名/包名]

## 使用场景示例
- [TODO]

## 验证是否装好
问它一个只有本技能 references 里才有答案的问题，例如：
> [TODO: 一个只有参考资料能回答的问题]

---
*本技能由 ima-skill-forge 从个人知识库自动锻造。*
"""


def main():
    ap = argparse.ArgumentParser(description="scaffold a product skill package")
    ap.add_argument("skill_dir", help="要创建的技能文件夹完整路径")
    ap.add_argument("--name", help="技能名(kebab-case)，默认取 skill_dir 最后一段")
    ap.add_argument("--title", default=None, help="中文标题，默认同 name")
    ap.add_argument("--author", default="Your Name", help="LICENSE 作者名")
    args = ap.parse_args()

    skill_dir = os.path.abspath(args.skill_dir)
    name = args.name or os.path.basename(skill_dir.rstrip("/\\"))
    title = args.title or name

    if not all(c.islower() or c.isdigit() or c == "-" for c in name):
        print(f"[WARN] name '{name}' 不是标准 kebab-case（仅小写字母/数字/连字符）")

    if os.path.exists(skill_dir):
        print(f"[ERROR] 目标已存在: {skill_dir}")
        sys.exit(1)

    os.makedirs(skill_dir)
    for d in ("references", "scripts", "assets"):
        os.makedirs(os.path.join(skill_dir, d))

    files = {
        "SKILL.md": SKILL_MD.format(name=name, title=title),
        "README.md": README_MD.format(title=title),
        "LICENSE": LICENSE_MD.format(year="2026", author=args.author),
        "CHANGELOG.md": CHANGELOG_MD,
    }
    for fn, content in files.items():
        with open(os.path.join(skill_dir, fn), "w", encoding="utf-8") as f:
            f.write(content)

    print(f"[OK] 已创建产物技能骨架: {skill_dir}")
    print(f"     目录: SKILL.md / README.md / LICENSE / CHANGELOG.md / references/ / scripts/ / assets/")
    print(f"     下一步: 写入 references 切片与正式 SKILL.md，再跑 validate.py")


if __name__ == "__main__":
    main()
