#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
validate.py — 校验「产物技能」是否符合 git 上传 / 平台安装规范。

用法:
    python3 scripts/validate.py <skill_dir>

检查项:
    1. SKILL.md 存在且 frontmatter 含 name / description
    2. name 与目录名一致，且为 kebab-case（≤40 字符）
    3. 所有文件 UTF-8 可解码（无乱码风险）
    4. 文件名 kebab-case（SKILL.md/README.md/LICENSE/CHANGELOG.md 例外）
    5. SKILL.md 正文 ≤ 400 行（超限提示拆分到 references/）
    6. 无空目录
    7. 扫描疑似敏感凭证（api key / password / token / cookie / secret）
退出码 0 = 全部通过；1 = 存在失败项。
"""
import os
import re
import sys
import argparse

MAX_SKILL_MD_LINES = 400
ALLOWED_SPECIAL_FILES = {"SKILL.md", "README.md", "LICENSE", "CHANGELOG.md"}
CREDENTIAL_RE = re.compile(
    r"(?i)(api[_-]?key|secret|password|passwd|token|cookie|access[_-]?key|private[_-]?key)\s*[:=]\s*['\"]?[A-Za-z0-9_\-]{8,}",
    re.MULTILINE,
)


def parse_frontmatter(path):
    with open(path, "r", encoding="utf-8") as f:
        text = f.read()
    if not text.startswith("---"):
        return None, text
    end = text.find("\n---", 3)
    if end == -1:
        return None, text
    block = text[3:end].strip("\n")
    body = text[end + 4:]
    meta = {}
    key = None
    for line in block.splitlines():
        m = re.match(r"^([A-Za-z_][\w-]*):\s*(.*)$", line)
        if m:
            key = m.group(1)
            meta[key] = m.group(2).strip()
        elif key and line.startswith((" ", "\t")):
            meta[key] += "\n" + line.strip()
    return meta, body


def is_kebab(s):
    return bool(re.fullmatch(r"[a-z0-9]+(-[a-z0-9]+)*", s))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("skill_dir")
    args = ap.parse_args()
    root = os.path.abspath(args.skill_dir)
    if not os.path.isdir(root):
        print(f"[ERROR] 目录不存在: {root}")
        sys.exit(1)

    errors, warns = [], []

    # 1 & 2: frontmatter + name
    skill_md = os.path.join(root, "SKILL.md")
    if not os.path.isfile(skill_md):
        errors.append("缺少必需文件 SKILL.md")
    else:
        meta, body = parse_frontmatter(skill_md)
        if meta is None:
            errors.append("SKILL.md 缺少合法 YAML frontmatter（以 --- 包裹）")
            meta = {}
        name = meta.get("name", "")
        desc = meta.get("description", "")
        dir_name = os.path.basename(root.rstrip("/\\"))
        if not name:
            errors.append("frontmatter 缺少 name")
        elif name != dir_name:
            errors.append(f"name '{name}' 与目录名 '{dir_name}' 不一致")
        if not is_kebab(name):
            errors.append(f"name '{name}' 不是 kebab-case（仅小写字母/数字/连字符）")
        if len(name) > 40:
            errors.append(f"name 超过 40 字符: {len(name)}")
        if not desc or "[TODO]" in desc:
            warns.append("description 缺失或仍为模板占位（会影响触发准确率）")

        # 5: SKILL.md 行数
        lines = body.count("\n") + 1
        if lines > MAX_SKILL_MD_LINES:
            warns.append(f"SKILL.md 正文 {lines} 行 > {MAX_SKILL_MD_LINES}，建议拆分到 references/")

    # 3,4,6,7: 遍历文件
    for dirpath, dirnames, filenames in os.walk(root):
        # 6: 空目录
        if not filenames and not dirnames:
            warns.append(f"空目录: {os.path.relpath(dirpath, root)}")
        for fn in filenames:
            fp = os.path.join(dirpath, fn)
            rel = os.path.relpath(fp, root)
            # 4: 文件名 kebab-case
            if fn not in ALLOWED_SPECIAL_FILES and fn.lower() != "qrcode.png":
                stem = fn.rsplit(".", 1)[0]
                if not is_kebab(stem):
                    warns.append(f"文件名非 kebab-case: {rel}")
            # 3: UTF-8
            try:
                with open(fp, "rb") as f:
                    f.read().decode("utf-8")
            except UnicodeDecodeError:
                errors.append(f"非 UTF-8 编码（乱码风险）: {rel}")
            # 7: 凭证
            try:
                with open(fp, "r", encoding="utf-8", errors="ignore") as f:
                    if CREDENTIAL_RE.search(f.read()):
                        warns.append(f"疑似含敏感凭证，请人工确认删除: {rel}")
            except Exception:
                pass

    # 报告
    print(f"=== validate: {root} ===")
    if warns:
        print("[WARN]")
        for w in warns:
            print(f"  - {w}")
    if errors:
        print("[FAIL]")
        for e in errors:
            print(f"  - {e}")
        print("结果: 未通过，请修复上方 [FAIL] 项后重新校验。")
        sys.exit(1)
    print("结果: 全部通过 ✅ 可进入 package.py 打包。")
    sys.exit(0)


if __name__ == "__main__":
    main()
